[Вернуться][main]

---

#  

---

[Вернуться][main]


[main]: ../../README.md "содержание"

[Pigeonhole_principle]: https://ru.wikipedia.org/wiki/Принцип_Дирихле_(комбинаторика) "pigeonhole principle"
